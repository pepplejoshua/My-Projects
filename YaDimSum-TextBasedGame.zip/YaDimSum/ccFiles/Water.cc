#include "../headers/Water.h"
#include <string>

string Water::getElement() const
{
  return "Water";
}
