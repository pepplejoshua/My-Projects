#include "../headers/Earth.h"
#include <string>

string Earth::getElement() const
{
  return "Earth";
}
