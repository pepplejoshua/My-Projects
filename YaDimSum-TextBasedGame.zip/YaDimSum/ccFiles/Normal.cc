#include "../headers/Normal.h"
#include <string>


string Normal::getElement() const
{
  return "Normal";
}
