#include "../headers/Air.h"
#include <string>

string Air::getElement() const
{
   return "Air";
}
