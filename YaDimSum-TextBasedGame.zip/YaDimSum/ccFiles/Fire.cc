#include "../headers/Fire.h"
#include <string>

string Fire::getElement() const
{
  return "Fire";
}
